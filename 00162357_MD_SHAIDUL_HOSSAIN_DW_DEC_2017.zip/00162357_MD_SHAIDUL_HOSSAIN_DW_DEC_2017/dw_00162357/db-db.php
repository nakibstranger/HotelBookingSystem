<?php
// Database connection script
function connect($setup=FALSE){
	$host = 'localhost';
	$username = 'root';
	$password = '';
	$database = 'dw_00162357';

	if($setup){
		$con = new mysqli($host, $username, $password);
	}else{
		$con = new mysqli($host, $username, $password, $database);
	}
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	} 
	
	return $con;
}


	
?>
<footer>
		<div class="container">
			<div class="row">
				<div class="col-xs-4">
					<div class="text-left">
						&copy; Copyright Euro Travels
					</div>
				</div>
				<div class="col-xs-4">
					Theme by <a href="http://www.themewagon.com">THEMEWAGON</a>
				</div>
				<div class="col-xs-4">
					<div class="top">
						<a href="index.php">
							<i class="ion-arrow-up-b"></i>
						</a>
					</div>
				</div>
			</div>
		</div>		
	</footer>


	<script src="<?=BASE_URL;?>assets/js/jquery-1.11.2.min.js"></script>
    <script src="<?=BASE_URL;?>assets/js/bootstrap.min.js"></script>
    <script src="<?=BASE_URL;?>assets/js/owl.carousel.min.js"></script>
    <script src="<?=BASE_URL;?>assets/js/contact.js"></script>
    <script src="<?=BASE_URL;?>assets/js/jquery.flexslider.js"></script>
	<script src="<?=BASE_URL;?>assets/js/script.js"></script>






</body>
</html>